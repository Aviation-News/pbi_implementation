from flask import Flask, render_template, jsonify, request, session, redirect, url_for
from flask_cors import CORS
import requests
import json
import os
import time
import uuid

app = Flask(__name__)
CORS(app, supports_credentials=True)  # Fix CORS issues
app.secret_key = os.environ.get('PBI_SECRET_KEY', 'change-me-pbi-saved-filters')  # stable key so sessions survive restart

# Default configuration
DEFAULT_CONFIG = {
  'tenant_id': '65693725-b6ed-4482-838d-454f6f79eafb',
  'client_id': '8264d2da-a712-455b-bb14-6e10d4db8676',
  'client_secret': 'gH68Q~DVK4FHki2hwdgOC4we8tF3nZMsM50FhcC9',
  'group_id': '8578855e-dbb3-47b0-b302-437d8572a9a3',
  'report_id': 'd32c0ba1-80fc-4e7a-99f6-f72d42ec61b7'
}

# Where saved filters live (JSON file next to this app)
FILTERS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'saved_filters.json')

# Key used to hold any pre-existing single-report saves so they aren't lost
# when we move to per-report bucketing.
LEGACY_BUCKET = '_legacy_unscoped'


def get_config():
    """Get the current configuration, either from session or default"""
    if 'config' in session:
        return session['config']
    return DEFAULT_CONFIG


def current_report_key():
    """Return the per-report bucket key for the current config.

    Saved filters are keyed by user + report so switching DEFAULT_CONFIG (or
    the in-session override) automatically gives a fresh, isolated list of
    saved sets per report.
    """
    cfg = get_config()
    return f"{cfg['group_id']}::{cfg['report_id']}"


def _load_all_filters():
    """Read the whole saved-filters store.

    Returns the new shape: {user_id: {report_key: [filter_records]}}.
    If the file is in the old shape (a list directly under the user), it is
    migrated in-memory under a LEGACY_BUCKET key so historical sets are kept
    but don't leak into any specific report's list.
    """
    if not os.path.exists(FILTERS_FILE):
        return {}
    try:
        with open(FILTERS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}

    if not isinstance(data, dict):
        return {}

    migrated = False
    for user_id, value in list(data.items()):
        # Old shape: value is a flat list of saved sets.
        if isinstance(value, list):
            data[user_id] = {LEGACY_BUCKET: value}
            migrated = True
        elif not isinstance(value, dict):
            # Junk row; drop it.
            data.pop(user_id, None)
            migrated = True

    return data


def _save_all_filters(data):
    """Write the whole store back to disk atomically-ish."""
    tmp = FILTERS_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, FILTERS_FILE)


def get_user_id():
    """The current user key (their name/email). None if not set."""
    return session.get('user_id')


def get_access_token():
    """Get Azure AD access token for Power BI API"""
    config = get_config()
    token_url = f"https://login.microsoftonline.com/{config['tenant_id']}/oauth2/v2.0/token"
    token_data = {
        'grant_type': 'client_credentials',
        'client_id': config['client_id'],
        'client_secret': config['client_secret'],
        'scope': 'https://analysis.windows.net/powerbi/api/.default'
    }

    response = requests.post(token_url, data=token_data)
    if response.status_code == 200:
        return response.json()['access_token']
    else:
        raise Exception(f"Failed to get token: {response.text}")


def get_embed_token():
    """Get Power BI embed token and report details"""
    config = get_config()
    access_token = get_access_token()
    embed_url = f"https://api.powerbi.com/v1.0/myorg/groups/{config['group_id']}/reports/{config['report_id']}/GenerateToken"

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    embed_data = {
        'accessLevel': 'View'
    }

    response = requests.post(embed_url, headers=headers, json=embed_data)

    if response.status_code == 200:
        embed_response = response.json()
        report_url = f"https://api.powerbi.com/v1.0/myorg/groups/{config['group_id']}/reports/{config['report_id']}"
        report_response = requests.get(report_url, headers=headers)

        if report_response.status_code == 200:
            report_data = report_response.json()
            return {
                'embed_token': embed_response['token'],
                'embed_url': report_data['embedUrl'],
                'report_id': config['report_id'],
                'group_id': config['group_id']
            }
        else:
            raise Exception(f"Failed to get report data: {report_response.text}")
    else:
        raise Exception(f"Failed to get embed token: {response.text}")


@app.route('/')
def index():
    """Main page with embedded Power BI report"""
    try:
        embed_data = get_embed_token()
        return render_template(
            'index.html',
            embed_token=embed_data['embed_token'],
            embed_url=embed_data['embed_url'],
            report_id=embed_data['report_id'],
            group_id=embed_data['group_id'],
            user_id=get_user_id() or ''
        )
    except Exception as e:
        return f"""
        <div style="padding: 20px; background: #f8d7da; color: #721c24; border-radius: 5px; margin: 20px;">
            <h2>Server Error</h2>
            <p><strong>Error:</strong> {str(e)}</p>
            <p><strong>Type:</strong> {type(e).__name__}</p>
            <hr>
            <p><a href="/test" style="color: #0078d4;">Try Test Endpoint</a></p>
            <p><a href="/reset" style="color: #0078d4;">Reset Configuration</a></p>
        </div>
        """


@app.route('/update_config', methods=['POST'])
def update_config():
    """Update the configuration with user-provided values"""
    try:
        config = get_config()
        if request.form.get('workspace_id'):
            config['group_id'] = request.form.get('workspace_id')
        if request.form.get('report_id'):
            config['report_id'] = request.form.get('report_id')
        session['config'] = config
        return redirect(url_for('index'))
    except Exception as e:
        return f"""
        <div style="padding: 20px; background: #f8d7da; color: #721c24; border-radius: 5px; margin: 20px;">
            <h2>Configuration Error</h2>
            <p><strong>Error:</strong> {str(e)}</p>
            <p><a href="/" style="color: #0078d4;">Back to Main Page</a></p>
            <p><a href="/reset" style="color: #0078d4;">Reset Configuration</a></p>
        </div>
        """


@app.route('/reset')
def reset_config():
    """Reset configuration to defaults"""
    if 'config' in session:
        session.pop('config')
    return redirect(url_for('index'))


@app.route('/test')
def test():
    """Test endpoint to verify token generation"""
    try:
        embed_data = get_embed_token()
        config = get_config()
        return jsonify({
            'success': True,
            'message': 'Embed token generated successfully!',
            'data': {
                'token_length': len(embed_data['embed_token']),
                'embed_url': embed_data['embed_url'],
                'report_id': embed_data['report_id'],
                'token_preview': embed_data['embed_token'][:50] + '...'
            },
            'config': {
                'tenant_id': config['tenant_id'],
                'client_id': config['client_id'],
                'group_id': config['group_id'],
                'report_id': config['report_id']
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'error_type': type(e).__name__
        }), 500


@app.route('/health')
def health():
    """Health check endpoint"""
    config = get_config()
    return jsonify({
        'status': 'healthy',
        'app': 'Power BI Embedded Demo',
        'port': 8080,
        'current_config': {
            'tenant_id': config['tenant_id'],
            'group_id': config['group_id'],
            'report_id': config['report_id']
        },
        'report_bucket': current_report_key(),
        'endpoints': {
            'main': 'http://localhost:8080/',
            'test': 'http://localhost:8080/test',
            'health': 'http://localhost:8080/health',
            'reset': 'http://localhost:8080/reset'
        }
    })


# ---------------------------------------------------------------------------
# User identity (simple name/email box, no real auth)
# ---------------------------------------------------------------------------
@app.route('/login', methods=['POST'])
def login():
    """Set the current user from a name/email box."""
    if request.is_json:
        user_id = (request.json or {}).get('user_id')
    else:
        user_id = request.form.get('user_id')
    user_id = (user_id or '').strip()
    if not user_id:
        return jsonify({'success': False, 'error': 'Name or email required'}), 400
    session['user_id'] = user_id
    if request.is_json:
        return jsonify({'success': True, 'user_id': user_id})
    return redirect(url_for('index'))


@app.route('/logout', methods=['POST', 'GET'])
def logout():
    """Clear the current user."""
    session.pop('user_id', None)
    if request.method == 'GET':
        return redirect(url_for('index'))
    return jsonify({'success': True})


@app.route('/whoami')
def whoami():
    return jsonify({'user_id': get_user_id(), 'report_bucket': current_report_key()})


# ---------------------------------------------------------------------------
# Saved filters API (keyed by user + report, stored in JSON file)
# ---------------------------------------------------------------------------
@app.route('/api/filters', methods=['GET'])
def list_filters():
    """List saved filter sets for the current user, scoped to the current report."""
    user_id = get_user_id()
    if not user_id:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401
    store = _load_all_filters()
    user_buckets = store.get(user_id, {})
    sets = user_buckets.get(current_report_key(), [])
    return jsonify({
        'success': True,
        'filters': sets,
        'report_bucket': current_report_key()
    })


@app.route('/api/filters', methods=['POST'])
def save_filters():
    """Save a named set of filters for the current user under the current report.

    Expected JSON body:
      { "name": "My view",
        "filters": { "filters": [...report filters...],
                     "slicers": [...slicer states...] } }
    (A bare list is also accepted for backward compatibility.)
    """
    user_id = get_user_id()
    if not user_id:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401

    body = request.get_json(silent=True) or {}
    name = (body.get('name') or '').strip()
    filters = body.get('filters')
    if not name:
        return jsonify({'success': False, 'error': 'Name required'}), 400
    if not isinstance(filters, (list, dict)):
        return jsonify({'success': False, 'error': 'filters must be a list or object'}), 400

    store = _load_all_filters()
    user_buckets = store.setdefault(user_id, {})
    report_key = current_report_key()
    sets_for_report = user_buckets.get(report_key, [])

    record = {
        'id': uuid.uuid4().hex,
        'name': name,
        'filters': filters,
        'saved_at': int(time.time()),
        'report_bucket': report_key
    }
    # If a set with the same name exists for this report, overwrite it.
    sets_for_report = [s for s in sets_for_report if s.get('name') != name]
    sets_for_report.append(record)
    user_buckets[report_key] = sets_for_report
    store[user_id] = user_buckets
    _save_all_filters(store)
    return jsonify({'success': True, 'filter': record, 'report_bucket': report_key})


@app.route('/api/filters/<filter_id>', methods=['DELETE'])
def delete_filter(filter_id):
    """Delete one saved filter set by id, scoped to the current user + report."""
    user_id = get_user_id()
    if not user_id:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401
    store = _load_all_filters()
    user_buckets = store.get(user_id, {})
    report_key = current_report_key()
    sets_for_report = user_buckets.get(report_key, [])
    new_sets = [s for s in sets_for_report if s.get('id') != filter_id]
    user_buckets[report_key] = new_sets
    store[user_id] = user_buckets
    _save_all_filters(store)
    return jsonify({'success': True, 'removed': len(sets_for_report) - len(new_sets)})


if __name__ == '__main__':
    print("=" * 50)
    print("Power BI Embedded Demo Starting...")
    print("=" * 50)
    print(f"Main App: http://localhost:8080/")
    print(f"Test API: http://localhost:8080/test")
    print(f"Health:   http://localhost:8080/health")
    print("=" * 50)
    print("Default Config:")
    print(f"   Tenant:  {DEFAULT_CONFIG['tenant_id']}")
    print(f"   Group:   {DEFAULT_CONFIG['group_id']}")
    print(f"   Report:  {DEFAULT_CONFIG['report_id']}")
    print("=" * 50)

    app.run(host='0.0.0.0', port=8080, debug=True)
